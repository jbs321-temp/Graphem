@extends('layouts.app')

@section('content')
<div id="root"></div>
@endsection
